-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 23, 2024 at 01:40 PM
-- Server version: 5.7.44-48-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbdcamrgdn5g2b`
--

-- --------------------------------------------------------

--
-- Table structure for table `tikapi__share`
--

CREATE TABLE `tikapi__share` (
  `id` int(11) NOT NULL,
  `share_key` varchar(255) NOT NULL DEFAULT '',
  `data` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tikapi__share`
--

INSERT INTO `tikapi__share` (`id`, `share_key`, `data`) VALUES
(1, 'ow1q1lg757ff5tjtojfcf', '[{\"dataType\":\"creator\",\"dataTag\":\"meesterjesper\",\"visType\":\"BigSingleShape\",\"shapeType\":\"skull\",\"color\":{\"r\":\"0.36625259558833256\",\"g\":\"0.8148465722120952\",\"b\":\"0.02732089163382382\"},\"visualID\":\"visual--BigSingleShape-creator-meesterjesper-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"humor\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.2501582847191642\",\"g\":\"0.17788841597328695\",\"b\":\"0.09758734713304495\"},\"visualID\":\"visual--DayHeightMap-hashtag-humor-1\"},{\"dataType\":\"hashtag\",\"dataTag\":\"humor\",\"visType\":\"DiamondsRing\",\"shapeType\":\"diamond\",\"color\":{\"r\":\"0.01764195448412081\",\"g\":\"0.8468732315065057\",\"b\":\"0.009134058699157796\"},\"visualID\":\"visual--DiamondsRing-hashtag-humor-2\"}]'),
(2, 'vi6yqgtx4dk3q0lva8fid', '[{\"dataType\":\"creator\",\"dataTag\":\"meesterjesper\",\"visType\":\"BigSingleShape\",\"shapeType\":\"skull\",\"color\":{\"r\":\"0.36625259558833256\",\"g\":\"0.8148465722120952\",\"b\":\"0.02732089163382382\"},\"visualID\":\"visual--BigSingleShape-creator-meesterjesper-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"humor\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.2501582847191642\",\"g\":\"0.17788841597328695\",\"b\":\"0.09758734713304495\"},\"visualID\":\"visual--DayHeightMap-hashtag-humor-1\"},{\"dataType\":\"hashtag\",\"dataTag\":\"humor\",\"visType\":\"DiamondsRing\",\"shapeType\":\"diamond\",\"color\":{\"r\":\"0.01764195448412081\",\"g\":\"0.8468732315065057\",\"b\":\"0.009134058699157796\"},\"visualID\":\"visual--DiamondsRing-hashtag-humor-2\"}]'),
(3, 'zlfpe77di7ak3fpl9op1t', '[{\"dataType\":\"hashtag\",\"dataTag\":\"nederland\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.33245153633549385\",\"g\":\"0.822785754392438\",\"b\":\"0.982250550332711\"},\"visualID\":\"visual--DayHeightMap-hashtag-nederland-0\"}]'),
(4, '7kh5jtks6vixfe03g4gxe', '[{\"dataType\":\"hashtag\",\"dataTag\":\"humor\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.0343398068028541\",\"g\":\"0.9734452903978066\",\"b\":\"0.20155625378383743\"},\"visualID\":\"visual--DayHeightMap-hashtag-humor-0\"}]'),
(5, 'y2h5vuacb3rs14m9vop5g', '[{\"dataType\":\"creator\",\"dataTag\":\"meesterjesper\",\"visType\":\"DiamondsRing\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.008023192982520563\",\"g\":\"0.6583748172725346\",\"b\":\"0.24620132669705552\"},\"visualID\":\"visual--DiamondsRing-creator-meesterjesper-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"nederland\",\"visType\":\"DayBoxes\",\"shapeType\":\"capsule\",\"color\":{\"r\":\"0.450785782828426\",\"g\":\"0.5840784178830671\",\"b\":\"0.514917665367466\"},\"visualID\":\"visual--DayBoxes-hashtag-nederland-1\"}]'),
(6, 'mdyxbd4y7s9qmnzrs8yz', '[{\"dataType\":\"hashtag\",\"dataTag\":\"dogdance\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.051269458367115384\",\"g\":\"0.35640014413537763\",\"b\":\"0.054480276435339814\"},\"visualID\":\"visual--DayHeightMap-hashtag-dogdance-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"echtemeisjesindejungle\",\"visType\":\"DayBoxes\",\"shapeType\":\"piramid\",\"color\":{\"r\":\"0.09758734713304495\",\"g\":\"0.9473065367320066\",\"b\":\"0.0006070539670588235\"},\"displaySpeed\":\"16\",\"visualID\":\"visual--DayBoxes-hashtag-echtemeisjesindejungle-1\"},{\"dataType\":\"hashtag\",\"dataTag\":\"banana\",\"visType\":\"DiamondsRing\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.9386857284565036\",\"g\":\"0.5647115056965487\",\"b\":\"0.05286064701616472\"},\"visualID\":\"visual--DiamondsRing-hashtag-banana-2\"},{\"dataType\":\"hashtag\",\"dataTag\":\"travel\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.22322795730611386\",\"g\":\"0.8387990117372213\",\"b\":\"0.10461648408208657\"},\"displaySpeed\":\"3\",\"visualID\":\"visual--DayHeightMap-hashtag-travel-3\"}]'),
(7, 'm52ajntr5kbb6htcwd73up', '[{\"shapeType\":\"DiamondsGridMini\",\"dataType\":\"reset4Cats\",\"dataTag\":\"*\",\"visType\":\"DiamondsGrid\",\"visualID\":\"visual--BigSingleShape-creator-meesterjesper-0\"}]'),
(8, 'ivh7pn8aqqvha6agixdn', '[{\"dataTag\":\"*\",\"visType\":\"DiamondsGrid\",\"shapeType\":\"DiamondsGridMini\",\"dataType\":\"categories\",\"color\":{\"r\":\"0.5972017883558645\",\"g\":\"0.0722718506743852\",\"b\":\"0.04518620437910499\"},\"visualID\":\"visual--DiamondsGrid-categories-*-0\",\"activeCats\":\"*\"}]'),
(9, 'bu5lywxr3usu9q4z7nid8', '[{\"dataType\":\"hashtag\",\"dataTag\":\"nba\",\"visType\":\"DayBoxes\",\"shapeType\":\"capsule\",\"color\":{\"r\":\"0.8962693533719567\",\"g\":\"0.02028856305209031\",\"b\":\"0.025186859622305935\"},\"visualID\":\"visual--DayBoxes-hashtag-nba-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"happybirthday\",\"visType\":\"DiamondsRing\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.7991027380100881\",\"g\":\"0.0781874217970207\",\"b\":\"0.07036009568874305\"},\"visualID\":\"visual--DiamondsRing-hashtag-happybirthday-1\"},{\"dataType\":\"hashtag\",\"dataTag\":\"usa\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.6866853124288865\",\"g\":\"0.508881320845802\",\"b\":\"0.0030352698352941175\"},\"displaySpeed\":\"20\",\"visualID\":\"visual--DayHeightMap-hashtag-usa-2\"},{\"dataType\":\"hashtag\",\"dataTag\":\"fashion\",\"visType\":\"BigSingleShape\",\"shapeType\":\"skull\",\"color\":{\"r\":\"0.0060488330203860696\",\"g\":\"0.015996293361446288\",\"b\":\"0.12477181755144427\"},\"displaySpeed\":\"1\",\"visualID\":\"visual--BigSingleShape-hashtag-fashion-3\"},{\"dataType\":\"hashtag\",\"dataTag\":\"shoes\",\"visType\":\"BigSingleShape\",\"shapeType\":\"rose\",\"color\":{\"r\":\"0.7156935005005721\",\"g\":\"0.033104766565152086\",\"b\":\"0.01764195448412081\"},\"displaySpeed\":\"5\",\"visualID\":\"visual--BigSingleShape-hashtag-shoes-4\"},{\"dataType\":\"hashtag\",\"dataTag\":\"basketball\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.33245153633549385\",\"g\":\"0.007499032040460618\",\"b\":\"0.015208514418949472\"},\"displaySpeed\":\"5\",\"visualID\":\"visual--DayHeightMap-hashtag-basketball-5\"},{\"dataType\":\"hashtag\",\"dataTag\":\"soap\",\"visType\":\"DayBoxes\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.5906188409113381\",\"g\":\"0.005605391621829107\",\"b\":\"0.36625259558833256\"},\"displaySpeed\":\"1\",\"visualID\":\"visual--DayBoxes-hashtag-soap-6\"},{\"dataType\":\"hashtag\",\"dataTag\":\"christmas2022\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.1844749944900301\",\"g\":\"0.014443843592229466\",\"b\":\"0.06301001764564068\"},\"displaySpeed\":\"8\",\"visualID\":\"visual--DayHeightMap-hashtag-christmas2022-7\"},{\"dataType\":\"hashtag\",\"dataTag\":\"miami\",\"visType\":\"DayBoxes\",\"shapeType\":\"piramid\",\"color\":{\"r\":\"0.5583403896257968\",\"g\":\"0.08865558627723595\",\"b\":\"0.775822218312646\"},\"displaySpeed\":\"19\",\"visualID\":\"visual--DayBoxes-hashtag-miami-8\"}]'),
(10, 'r2hzm66u59m9q40trl1i8', '[{\"dataType\":\"hashtag\",\"dataTag\":\"girlboss\",\"visType\":\"DayBoxes\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.8148465722120952\",\"g\":\"0.8148465722120952\",\"b\":\"0.6375968739867731\"},\"visualID\":\"visual--DayBoxes-hashtag-girlboss-0\"},{\"dataType\":\"hashtag\",\"dataTag\":\"fashion\",\"visType\":\"BigSingleShape\",\"shapeType\":\"rose\",\"color\":{\"r\":\"0.7454042095350284\",\"g\":\"0.0060488330203860696\",\"b\":\"0.019382360952473074\"},\"visualID\":\"visual--BigSingleShape-hashtag-fashion-1\"},{\"dataType\":\"hashtag\",\"dataTag\":\"cute\",\"visType\":\"DiamondsRing\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.651405637412793\",\"g\":\"0.2501582847191642\",\"b\":\"0.29613827078752575\"},\"visualID\":\"visual--DiamondsRing-hashtag-cute-2\"},{\"dataType\":\"hashtag\",\"dataTag\":\"thierrybaudet\",\"visType\":\"BigSingleShape\",\"shapeType\":\"heart\",\"color\":{\"r\":\"0.7156935005005721\",\"g\":\"0.1878207722902346\",\"b\":\"0.3277780980458375\"},\"visualID\":\"visual--BigSingleShape-hashtag-thierrybaudet-3\"}]'),
(11, 'asas8d3l35nhj5qqjfvb37', '[{\"dataType\":\"hashtag\",\"dataTag\":\"cute\",\"visType\":\"DiamondsRing\",\"shapeType\":\"diamond\",\"color\":{\"r\":\"0.05286064701616472\",\"g\":\"0.55201140150344\",\"b\":\"0.6375968739867731\"},\"visualID\":\"visual--DiamondsRing-hashtag-cute-2\"},{\"dataType\":\"hashtag\",\"dataTag\":\"football\",\"visType\":\"DayHeightMap\",\"color\":{\"r\":\"0.9646862478936612\",\"g\":\"0.6724431569510133\",\"b\":\"0.02121901037134225\"},\"visualID\":\"visual--DayHeightMap-hashtag-football-3\"}]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tikapi__share`
--
ALTER TABLE `tikapi__share`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tikapi__share`
--
ALTER TABLE `tikapi__share`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
